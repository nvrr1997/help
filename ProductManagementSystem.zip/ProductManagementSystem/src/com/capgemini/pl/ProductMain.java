package com.capgemini.pl;

import java.time.LocalDate;


import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.exceptions.InvalidOrderException;
import com.capgemini.exceptions.InvalidProductException;
import com.capgemini.exceptions.ProductDBException;
import com.capgemini.service.ProductService;
import com.capgemini.service.ProductServiceImpl;

public class ProductMain 
{
  public static void main(String[] args)
  {
	    Scanner sc=new Scanner(System.in);
	 ProductService pser = new ProductServiceImpl();
	 do
	 {
		 System.out.println("Menu \n 1.Add Product");
		 System.out.println("2. Delete Product \n  3. Show all Product");
	     System.out.println("4.Place Order");
	     System.out.println("5.Search Product");
	     System.out.println("6.Exit");
	     System.out.println("Enter your choice");
	     int choice = sc.nextInt();
	     switch(choice)
	     {
	     case 1:
	    	    System.out.println("Enter Product Name:");
	    	    String pname=sc.next();
	    	    System.out.println("Enter Product Price:");
	    	    double price=sc.nextDouble();
	    	    Product p=new Product(0, price,pname);
	    	    try
	    	    {
	    		     if(pser.validateProduct(p))
	    		     {
	    			    pser.addProduct(p);
	    			    System.out.println("Product inserted in table with id");
	    		     }
	    	    }
	    
	    	    catch(ProductDBException e)
	    	    {
	    		    System.out.println(e.getMessage());
	    	    }
	    	    break;
	     case 2:
	    	  System.out.println("Enter productID:");
	    	  long productId=sc.nextLong();
	    	  pser.deleteProduct(productId);
	    	  System.out.println("Deleted Successfully");
	    	  break;
	    	  
	     case 3:
	    	   try{
	    		   List<Product> plist=pser.getAllProduct();
	    		   if(plist.size()==0)
	    		   {
	    			   System.out.println("No Product available");
	    		   }   else
	    			   {
	    				   for(Product p1:plist)
	    				   {
	    					   System.out.println(p1);
	    			       }
	    			   }  
	    		   } 
	    	    catch(ProductDBException e){
	    	    	System.out.println(e.getMessage());
	    	    }
	    	   break;
	     case 4:
	    	   System.out.println("Enter product id to order");
	    	   int pid=sc.nextInt();
	    	   System.out.println("Enter quantity:");
	    	   int qty=sc.nextInt();
	    	   System.out.println("Enter order date in dd/mm/yyyy format:");
	    	   String ordDateStr = sc.next();		   
	    			   
	    			   
	    		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    	   LocalDate ordDate= LocalDate.parse(ordDateStr, format);
	    	   Order order = new Order(0, pid, qty, 0, ordDate);
	    	/*   try {
				pser.addOrder(order);
			} catch (ProductDBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				System.out.println("Order placed with id "+order.getOrderId());
				System.out.println("Total amount to pay "+order.getTotalAmount());*/
	    	   	try{
	    			if(pser.searchProduct(pid)==null)
	    			{
	    				System.out.println("Product not available with "+pid);
	    			}
	    			else{
	    				if(pser.validateOrder(order))
	    				{
	    					pser.addOrder(order);
	    					System.out.println("Order placed with id "+order.getOrderId());
	    					System.out.println("Total amount to pay "+order.getTotalAmount());
	    				}
	    			}
	    		}
	    		catch (InvalidOrderException e)
	    		{
	    			System.out.println(e.getMessage());
	    		}
	    		catch (ProductDBException e)
	    		{
	    			System.out.println(e.getMessage());
	    		} catch (InvalidProductException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    		break;
	    			   
	     case 5:
	            System.out.println("Enter ProductID:");
	            long pId=sc.nextLong();
	            Product product=pser.searchProduct(pId);
	            System.out.println(product);
	    	   break;
	    	         
	       case 6: System.exit(0);
	       default: System.out.println("Invalid Choice try again");
	     }
	  } while(true);
	 
   }
}
