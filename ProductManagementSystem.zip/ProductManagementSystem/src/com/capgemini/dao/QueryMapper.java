package com.capgemini.dao;

public interface QueryMapper {
	
	public static final String 
	INSERTQUERY="insert into products values(?,?,?)";
	
	/*public static final String
	ORDERQUERY="insert into product_order values(?,?,?,?,?)";*/
	
	public static final String 
	DELETEPRODUCT="delete from products where productId=?";
	
	public static final String 
	SELECTQUERY="select productPrice,productName,productId from products";
	
	public static final String
	SEARCHQUERY="select productPrice,productName,productId from products where productId=?";
	
	

}
