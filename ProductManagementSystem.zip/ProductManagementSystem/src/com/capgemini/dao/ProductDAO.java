package com.capgemini.dao;

import java.util.List;
import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.exceptions.InvalidOrderException;
import com.capgemini.exceptions.ProductDBException;

public interface ProductDAO {

	public List<Product> getAllProduct() throws ProductDBException;
	public Product searchProduct(long productId);
	public long addProduct(Product product); 
	public long addOrder(Order order) throws InvalidOrderException,ProductDBException;
	public long deleteProduct(long productId);              

}
