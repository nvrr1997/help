package com.capgemini.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.exceptions.ProductDBException;
import com.capgemini.util.DBUtil;


public class ProductDAOImpl implements ProductDAO {
	Connection con;

	@Override
	public List<Product> getAllProduct() {
	 List<Product> productList=new ArrayList<Product>();
	 con=DBUtil.getConnection();
     try{
    	 Statement statement=con.createStatement();
    	 ResultSet resultSet=statement.executeQuery(QueryMapper.SELECTQUERY);
    	 while(resultSet.next())
    	 {
    		 Product product=new Product();
    	     product.setProductId(resultSet.getLong(3));
    	     product.setProductName(resultSet.getString(2));
    	     product.setProductPrice(resultSet.getDouble(1));
    	     productList.add(product);
    	 }
     }
     catch(SQLException e)
     {
    	 e.printStackTrace();
     }
	 return productList;
	}

	@Override
	public Product searchProduct(long productId) {
	        Product product=new Product();
			con=DBUtil.getConnection();
			try
			{
				PreparedStatement preparedStatement=con.prepareStatement(QueryMapper.SEARCHQUERY);
				preparedStatement.setLong(1,productId);
			     
				ResultSet resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
				{
					product.setProductId(resultSet.getLong("productId"));
					product.setProductName(resultSet.getString("productName"));
					product.setProductPrice(resultSet.getDouble("productPrice"));
				}
			}
			catch(SQLException e)
			{ 
				e.printStackTrace();
			}
			return product;
	}

	public long generateProductId()
	{
		long productId=0;
		String SQL="select Products_SEQ.nextval from dual";
		con=DBUtil.getConnection();
		try{
			Statement statement = con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			productId=resultSet.getLong(1);
		}
		catch(Exception e){
			System.out.println("Problem Occured while generating Product");
		}
		return productId;
	}

	@Override
	public long addProduct(Product product) {
        long productId=generateProductId();
		con=DBUtil.getConnection();
		try
		{
			PreparedStatement preparedStatement=con.
			prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setLong(1,productId);
			preparedStatement.setDouble(2,product.getProductPrice());
			preparedStatement.setString(3,product.getProductName());
			preparedStatement.executeUpdate();
			
			/* 
			  
			  
			 
			 */
		}
		catch(SQLException e)
		{
			
			e.printStackTrace();
		}
		return productId;

	}

	@Override
	public long addOrder(Order order) throws ProductDBException {
		String sql="INSERT INTO product_order values(?,?,?,?,?)";
		order.setOrderId(generateProductId());
		System.out.println(order);
		con=DBUtil.getConnection();
		try{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setLong(1,order.getOrderId());
			pst.setLong(2,order.getProductId());
			pst.setInt(3,order.getQuantity());
			pst.setDouble(4,order.getTotalAmount());
			pst.setDate(5, Date.valueOf(order.getOrderDate()));
			pst.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new ProductDBException("Problem in inserting order "+ "details "+e.getMessage());
		}
		return order.getOrderId();
	}
	
	private long generateOrderID() throws ProductDBException{
		long oid =0;
		String sql = "SELECT Order_seq.NEXTVAL FROM dual";
		con = DBUtil.getConnection();
		try{
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			rst.next();
			oid=rst.getLong(1);
		  }
		  catch(SQLException e)
		  {
			  throw new ProductDBException("Problem in generating product id"+e.getMessage());
		  }
		return oid;
	}

	@Override
	public long deleteProduct(long productId) {
	       con=DBUtil.getConnection();
	       try
	       {
	    	    PreparedStatement preparedstatement =con.prepareStatement(QueryMapper.DELETEPRODUCT);
	    	    preparedstatement.setLong(1,productId);
	    	    preparedstatement.executeUpdate();
	       }
	       catch(SQLException e)
	       {
	    	   e.printStackTrace();
	       }
	       return productId;
	}
}
