package com.capgemini.exceptions;

public class InvalidProductException extends Exception {
	
	public InvalidProductException()
	{
		
	}

}
