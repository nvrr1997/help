package com.capgemini.exceptions;

public class InvalidOrderException extends Exception{

	public InvalidOrderException()
	{
		
	}
}
