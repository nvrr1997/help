package com.capgemini.exceptions;

public class ProductDBException extends Exception {
	
	public ProductDBException(String message){
		super(message);
	}

}
