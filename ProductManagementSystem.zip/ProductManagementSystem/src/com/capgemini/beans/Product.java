package com.capgemini.beans;

/**
 * 
 * @author VenkatRamReddy
 *
 */

public class Product {

	private long productId;
	private double productPrice;
	private String productName;
	public Product()
	{
		//TODO Auto generated constructor stub
	}

	public Product(long productId, double productPrice, String productName) {
		super();
		this.productId = productId;
		this.productPrice = productPrice;
		this.productName = productName;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productPrice="
				+ productPrice + ", productName=" + productName + "]";
	}


}
