package com.capgemini.service;

import java.util.List;




import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.dao.ProductDAO;
import com.capgemini.dao.ProductDAOImpl;
import com.capgemini.exceptions.InvalidOrderException;
import com.capgemini.exceptions.InvalidProductException;
import com.capgemini.exceptions.ProductDBException;

public class ProductServiceImpl implements ProductService {
	ProductDAO dao=new ProductDAOImpl();

	@Override
	public List<Product> getAllProduct() throws ProductDBException {
		// TODO Auto-generated method stub
		return dao.getAllProduct();
	}

	@Override
	public Product searchProduct(long productId) {
		
		dao.searchProduct(productId);
		return dao.searchProduct(productId);
	}

	@Override
	public long addProduct(Product product) {
		    dao.addProduct(product);
			return product.getProductId();
	}

	@Override
	public long addOrder(Order order) throws InvalidOrderException, ProductDBException{
	   return dao.addOrder(order);
	   
	}

	@Override
	public long deleteProduct(long productId) {
		// TODO Auto-generated method stub
		dao.deleteProduct(productId);
		return 0;
	}

	@Override
	public boolean validateProduct(Product product)
	{
		if(product.getProductPrice() <=0)
		{
			try{
			throw new InvalidProductException();
		  }
	 		
		  catch(InvalidProductException e)
		  {
			e.printStackTrace();
		   }
	
		}
		return true;
	}

	@Override
	public boolean validateOrder(Order order)  throws InvalidOrderException, ProductDBException {
		// TODO Auto-generated method stub
		return false;
	}

}
