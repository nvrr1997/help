package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Order;
import com.capgemini.beans.Product;
import com.capgemini.exceptions.InvalidOrderException;
import com.capgemini.exceptions.InvalidProductException;
import com.capgemini.exceptions.ProductDBException;

public interface ProductService {
	public List<Product> getAllProduct() throws ProductDBException;
	public Product searchProduct(long productId);
	public long addProduct(Product product) throws ProductDBException;
	public long addOrder(Order order) throws ProductDBException, InvalidOrderException;
	public long deleteProduct(long productId); 
	
	public boolean validateProduct(Product product);
	public boolean validateOrder(Order order) throws InvalidProductException, InvalidOrderException, ProductDBException;

}
