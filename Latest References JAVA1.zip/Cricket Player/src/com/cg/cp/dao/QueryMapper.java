package com.cg.cp.dao;

public interface QueryMapper {
	public static final String INSERT_PLAYER_QUERY="INSERT INTO players VALUES(?,?,?,?,?,?)";

	public static final String PLAYERID_SEQUENCE_QUERY = "SELECT players_seq.NEXTVAL FROM DUAL";

	public static final String RETRIVE_ALL_PLAYERS_QUERY = "SELECT * FROM players";
	public static final String RETRIEVE_PLAYER_BY_ID = "Select * from players where playerid = ?";

}
