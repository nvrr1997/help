package com.cg.cp.testcases;

import static org.junit.Assert.*;

import javax.security.auth.login.AccountException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.bean.PlayerBean;
import com.cg.cp.dao.daoPlayerImpl;

public class testcases {

	static daoPlayerImpl mdaoimpl;
	static PlayerBean playerbean;

	@BeforeClass
	public static void intialize() throws PlayerException {

		mdaoimpl = new daoPlayerImpl();
		playerbean = new PlayerBean();
	}

	@Test
	public void addPlayerdetails() throws PlayerException {
		playerbean.setPlayerId("1001");
		playerbean.setBirthDate("10/10/2000");
		playerbean.setPlayerName("Sankar");
		playerbean.setRole("bowler");
		playerbean.setTeamName("KKR");

		assertTrue("details added successfully",
				Integer.parseInt(mdaoimpl.addNewPlayer(playerbean)) > 1000);
	}

	@Test
	public void testPlayerId() throws PlayerException {

		String tid = mdaoimpl.generatePlayerId();
		assertEquals("Test Correct", Integer.parseInt(tid) + 1,
				Integer.parseInt(mdaoimpl.generatePlayerId()));
	}

	@Test
	public void testTrainDetails() throws PlayerException {
		assertNotNull(mdaoimpl.getAllplayers());
	}

	@Test
	public void testById() throws PlayerException {
		assertNotNull("TestName", mdaoimpl.getPlayerDetailbyId(3000));
	}
	
	


}
