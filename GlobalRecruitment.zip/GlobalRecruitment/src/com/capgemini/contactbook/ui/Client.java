package com.capgemini.contactbook.ui;

import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookxception;
import com.capgemini.contactbook.service.EnquiryBeanService;
import com.capgemini.contactbook.service.EnquiryBeanServiceImpl;




public class Client {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	EnquiryBeanService service=new EnquiryBeanServiceImpl();
	do{
		System.out.println("**********Global Recruitments***********");
		System.out.println("Choose an Operation");
		System.out.println("1. Enter Enquiry Details");
		System.out.println("2. Enquiry Details on Id");
		System.out.println("3. Exit");
		System.out.println("Enter your choice");
		int choice=scanner.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter First Name:");
			String fname=scanner.next();
			System.out.println("Enter Last Name:");
			String lname=scanner.next();
			System.out.println("Enter Contact Number:");
			String con=scanner.next();
			System.out.println("Enter Preferred Domain:");
			String domain=scanner.next();
			System.out.println("Enter Preferred Location:");
			String location=scanner.next();
			EnquiryBean bean=new EnquiryBean(0,fname,lname,con,domain,location);
			
				try {if(service.isValidEnquiry(bean)){
					service.addEnquiry(bean);
				
					System.out.println("Thank You "+fname +" "+lname+ "Your Unique Id is" +service.getEmployeeId()+
							"we Will contact you shortly");}
				}
				 catch (ContactBookxception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			break;
		case 2:
			System.out.println("Enter Enqryid");
			int id=scanner.nextInt();
			
			try {
				
				
				EnquiryBean bean1=service.getEnquiryDetails(id);
				System.out.println(bean1);
				
				
			} catch (ContactBookxception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		}while(true);
	}
}

