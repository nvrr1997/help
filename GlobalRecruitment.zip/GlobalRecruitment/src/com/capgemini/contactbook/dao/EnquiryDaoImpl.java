package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookxception;
import com.capgemini.contactbook.util.DBUtil;


public class EnquiryDaoImpl implements EnquiryDao{
	Connection con;

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookxception {
		// TODO Auto-generated method stub
		int enqryId=generateEnqryId();
		con = DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(QueryMapper.insert);
			preparedstatement.setLong(1,enqryId);
			preparedstatement.setString(2,enqry.getfName());
			preparedstatement.setString(3,enqry.getlName());
			preparedstatement.setString(4,enqry.getContactNo());
			preparedstatement.setString(5,enqry.getpDomain());
			preparedstatement.setString(6,enqry.getpLocation());
			preparedstatement.executeUpdate();
			/*preparedstatement = con.prepareStatement(QueryMapper.Customer_QUERY_SEQUENCE);
			Statement statement=con.createStatement();
			ResultSet  resultset = preparedstatement.executeQuery();
			resultset.next();
			System.out.println("you Productid is "+resultset.getString(1));*/
		} catch (SQLException e) {
			throw new ContactBookxception(e.getMessage());
		}

		return enqryId;
	}
	

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookxception{
	EnquiryBean enq=new EnquiryBean();
	// TODO Auto-generated method stub
	con=DBUtil.getConnection();
	try {
		PreparedStatement preparedstatement = con
				.prepareStatement(QueryMapper.search);
		preparedstatement.setInt(1,EnquiryId);
	ResultSet resultset=preparedstatement.executeQuery();
	
	while(resultset.next()){
		enq.setEnqryId(resultset.getInt("enqryid"));
		enq.setfName(resultset.getString("firstname"));
		enq.setlName(resultset.getString("lastname"));
		enq.setContactNo(resultset.getString("contactno"));
		enq.setpDomain(resultset.getString("domain"));
		enq.setpLocation(resultset.getString("city"));
		
	}
		
	
	} catch (SQLException e) {
	throw new ContactBookxception(e.getMessage());
	}
	return enq;

}
	
	public int generateEnqryId() throws ContactBookxception{
		int Enqryid=0;
			String SQL = "select enquiry_global.nextval from dual";
			con = DBUtil.getConnection();
			try {
				Statement statement = con.createStatement();
				ResultSet resultset = statement.executeQuery(SQL);
				resultset.next();
				Enqryid = resultset.getInt(1);
				//System.out.println(FlatRegNo);
			} catch (SQLException e) {
				throw new ContactBookxception(e.getMessage());
			}
			return Enqryid;
		}
	public int getEmployeeId() throws ContactBookxception
	{
		int id=0;
		String query="Select enquiry_global.currval from dual";
		try
		{
	Statement stmt=con.createStatement();
	ResultSet rs=stmt.executeQuery(query);
	if(rs.next())
	{
		id=rs.getInt(1);
	}
		}
		catch(SQLException e)
		{
			throw new ContactBookxception(e.getMessage());
		}
		return id;
	}
	

	
}
