package com.cg.frs.dao;

public class QueryMapper {
	public static final String SELECTQUERY="select owner_id from flat_owners";
	public static final String INSERTQUERY="insert into flat_registration values(?,?,?,?,?,?)";
	

}
