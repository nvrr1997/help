package com.cg.frs.exception;

public class RegistrationException extends Exception {

	public RegistrationException(String string) {
		super(string);
	}

}
