package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDao;
import com.capgemini.dao.TrainDaoImpl;


public class TrainServiceImpl implements TrainService{
	TrainDao dao=new TrainDaoImpl();

	public void setDao(TrainDaoImpl dao)
	{
		this.dao=dao;
	}
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() {
		// TODO Auto-generated method stub
		return dao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException {
		// TODO Auto-generated method stub
		dao.bookTicket(bookingbean);
		return bookingbean.getBookingId();
	}

	@Override
	public int generateBookingId() {
		// TODO Auto-generated method stub
		return dao.generateBookingId();
	}

	@Override
	public boolean validateBookingDetails(BookingBean bookingbean) throws BookingException {
		ArrayList<TrainBean> trains=dao.retrieveTrainDetails();
		if(trains.stream().filter(da->da.getTrainId()==bookingbean.getTrainId()).count()==0){
			throw new BookingException("Invalid train id");
		}
		return true;
		
	}


}
