package com.capgemini.dao;

public class QueryMapper {
	public static final String INSERTQUERY="insert into bookingdetails values(?,?,?,?)";
	public static final String SELECTQUERY="select * from traindetails";
			
	
	
	
	
}
