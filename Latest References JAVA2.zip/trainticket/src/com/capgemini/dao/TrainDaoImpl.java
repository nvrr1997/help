package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.utility.DBUtil;

public class TrainDaoImpl implements TrainDao{
Connection connection=null;
  	  @Override
    	public ArrayList<TrainBean> retrieveTrainDetails() {
    		ArrayList<TrainBean> trainlist = new ArrayList<TrainBean>();
    		connection = DBUtil.getConnection();
    		Statement statement;
    		try {
    			statement = connection.createStatement();
    			ResultSet resultSet = statement
    					.executeQuery(QueryMapper.SELECTQUERY);
    			
    			while (resultSet.next()) {
    				TrainBean tb= new TrainBean();
    				tb.setTrainId(resultSet.getInt(1));
    				tb.setTrainType(resultSet.getString(2));
    				tb.setFromStop(resultSet.getString(3));
    				tb.setToStop(resultSet.getString(4));
    				tb.setAvailableSeats(resultSet.getInt(5));
    				tb.setFare(resultSet.getInt(6));
    				tb.setDateOfJourney(resultSet.getDate(7));
    				trainlist.add(tb);
    
    			}
    		} catch (SQLException e) {
    			   
    			e.printStackTrace();
    		}
  
		return trainlist;
		}

  	@Override
	public int generateBookingId() {
		  
		int BookingId = 0;
		String SQL = "select booking_id_seq.nextval from dual";
		connection = DBUtil.getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			BookingId = resultSet.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return BookingId;
	}
	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException {
		 // TODO Auto-generated method stub
		connection = DBUtil.getConnection();
		int BookingId=generateBookingId();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setInt(1,BookingId);
			preparedStatement.setInt(2, bookingbean.getNoOfseat());
			preparedStatement.setInt(3, bookingbean.getTrainId());
			preparedStatement.setString(4, bookingbean.getCustId());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return BookingId;
	}
	
		
	}


