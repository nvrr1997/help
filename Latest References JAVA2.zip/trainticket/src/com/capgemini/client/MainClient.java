package com.capgemini.client;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.service.TrainService;
import com.capgemini.service.TrainServiceImpl;


public class MainClient {
public static void main(String[] args) throws BookingException {
	TrainService service=new TrainServiceImpl();
System.out.println("Railway booking system");	
System.out.println();
System.out.println("enter 1 for booking ");
System.out.println("enter 2 for exit ");
Scanner sc=new Scanner(System.in);
int choice=sc.nextInt();
switch(choice)
{
case 1:
	ArrayList<TrainBean> trains=service.retrieveTrainDetails();
	for(TrainBean t:trains)	{
		System.out.println(t);
		}
	System.out.println("enter number of seats");
	 int noOfseat=sc.nextInt();
	System.out.println("enter trainid");
	int trainid=sc.nextInt();
	System.out.println("enter custid");
	String custId=sc.next();
	BookingBean bb=new BookingBean(noOfseat, trainid, custId);
	
	/*service.bookTicket(bb);
	System.out.println("Successfully booked with train id "+service.generateBookingId());
	*/
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	try {
		if (service.validateBookingDetails(bb)) {
			service.bookTicket(bb);
			System.out.println("Registered Successfully with PurchaseId : "
							+ service.generateBookingId());
		}
	} catch (BookingException e) {
		System.err.println(e.getMessage());
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	System.out.println("Do you want to continue press 1 for continue || 2 for exit");
	int selection=sc.nextInt();
	if(selection==1)
	{
	MainClient.main(args);
	}
	else if(selection==2)
	{
		System.out.println("System Successfully Exited");
		System.exit(0);	
	}
	else
	{
		System.out.println("wrong choice");
		
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	case 2:	
	System.out.println("System Successfully Exited");
	System.exit(0);
  break;

default:
	System.out.println("Invalid Choice");
	break;	
	
	
}

}

}
