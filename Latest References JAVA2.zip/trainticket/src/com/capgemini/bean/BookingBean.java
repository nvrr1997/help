package com.capgemini.bean;

public class BookingBean {
	private int bookingId;
	private int noOfseat;
	private int trainId;
	private String custId;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getNoOfseat() {
		return noOfseat;
	}
	public void setNoOfseat(int noOfseat) {
		this.noOfseat = noOfseat;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public BookingBean() {
		// TODO Auto-generated constructor stub
	}

	public BookingBean(int noOfseat, int trainId, String custId) {
		super();
		//this.bookingId = bookingId;
		this.noOfseat = noOfseat;
		this.trainId = trainId;
		this.custId = custId;
	}
	

}
