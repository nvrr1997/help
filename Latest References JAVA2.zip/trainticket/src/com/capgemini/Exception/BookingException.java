package com.capgemini.Exception;

public class BookingException extends Exception{
	
	public BookingException(String str)
	{
		super(str);
	}
	
	

}
