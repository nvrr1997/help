package com.cg.student.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.student.beans.Student;
import com.cg.student.dao.StudentDao;
import com.cg.student.dao.StudentDaoImpl;
import com.cg.student.exceptions.StudentException;
import com.cg.student.service.StudentServiceImpl;

public class StudentDaoTestc {
StudentServiceImpl service;
StudentDao dao;
@Before
public void init(){
	dao=new StudentDaoImpl();
	service=new StudentServiceImpl();
	service.setDao(dao);
}@Test
public void testGetAllStudent() throws StudentException{
	ArrayList<Student>list=service.getAllStudent();
	assertNotNull(list);
}
@Test
public void testAddStudent() throws StudentException{
	Student std=new Student();
	std.setStdName("sai");
			std.setAge(23);
			std.setDob(LocalDate.of(1996, Month.OCTOBER,30 ));
			int id=service.addStudent(std);
			assertNotSame(id,0);
}
@Test
public void testDeleteStudent() throws StudentException{
	int std=service.deleteStudentById(2000);
	assertNotNull(std);
}@After
public void destory(){
	
dao=null;
service=null;
}

	
}
