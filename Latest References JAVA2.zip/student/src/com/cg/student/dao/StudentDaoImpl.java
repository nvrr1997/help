package com.cg.student.dao;

import java.lang.Thread.State;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;
import com.cg.student.util.DBUtil;

public class StudentDaoImpl implements StudentDao{
Connection con;
int studentId;
PreparedStatement preparedStatement;

	public StudentDaoImpl() {
	con=DBUtil.getConnection();
	}
public int generateStudentId() throws StudentException{
	int id=0;
	String SQL="select sud_seq.currval from dual";
	try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(SQL);
		if(rs.next())
		{
			id=rs.getInt(1);
		}
	} catch (SQLException e) {
		throw new StudentException(e.getMessage());
	}
	return id;
	
}
	@Override
	public int addStudent(Student obj) throws StudentException {
		con=DBUtil.getConnection();
		
		try {
			preparedStatement=con.prepareStatement(QueryMapper.INSERTQUERY);
	
	//preparedStatement.setInt(1, studentId);
	preparedStatement.setString(1, obj.getStdName());
	preparedStatement.setLong(2, obj.getPhoneNumber());
	java.sql.Date date=Date.valueOf(obj.getDob());
	preparedStatement.setDate(3, date);
	preparedStatement.setString(4, obj.getStandard());
	preparedStatement.setInt(5, obj.getAge());
	preparedStatement.executeUpdate();

	
	
	
	
		} catch (SQLException e) {
		throw new StudentException(e.getMessage());
			
		}
		return studentId;
	}

	@Override
	public int deleteStudentById(int studentId) throws StudentException {
	con=DBUtil.getConnection();
	int t=0;
	try {
		preparedStatement=con.prepareStatement(QueryMapper.deletequery);
	preparedStatement.setInt(1, studentId);
	 t=preparedStatement.executeUpdate();
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		return t;
	}

	@Override
	public Student getStudentById(int studentId) throws StudentException {
		con=DBUtil.getConnection();
		Student std=null;
		try {
			preparedStatement=con.prepareStatement(QueryMapper.searchId);
		preparedStatement.setInt(1, studentId);
		ResultSet rs=preparedStatement.executeQuery();
		if(rs.next()){
			int id=rs.getInt(1);
		String name=rs.getString(2);
		long phone=rs.getLong(3);
		LocalDate date=rs.getDate(4).toLocalDate();
		String stand=rs.getString(5);
		int ag=rs.getInt(6);
		std=new Student(id,name,phone,date,stand,ag);
		
		}
		
		} catch (SQLException e) {
			
			throw new StudentException(e.getMessage());
		}
		
		return std;
	}

	@Override
	public ArrayList<Student> getAllStudent() throws StudentException {
		ArrayList<Student>List=new ArrayList<Student>();
	
	try {
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(QueryMapper.allStudent);
		while(rs.next()){
			int id=rs.getInt(1);
			String name=rs.getString(2);
			long phone=rs.getLong(3);
			LocalDate date= rs.getDate(4).toLocalDate();
			String stand=rs.getString(5);
			int ag=rs.getInt(6);
			Student std=new Student(id,name,phone,date,stand,ag);
			List.add(std);
			
			
		}
	} catch (SQLException e) {
		throw new StudentException(e.getMessage());
	}
	
	
		return List;
	}

	@Override
	public int updatePhoneNumber(int studentId, long phoneNumber)throws StudentException {
		try {
			preparedStatement=con.prepareStatement(QueryMapper. updatequery);
			preparedStatement.setLong(1, phoneNumber);
		preparedStatement.setInt(2, studentId);
		
		int s=preparedStatement.executeUpdate();
		return s;
		} catch (SQLException e) {
			throw new StudentException(e.getMessage());
		}
		
	
	}

	

}
