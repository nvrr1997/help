package com.cg.student.dao;

import java.util.ArrayList;

import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;

public interface StudentDao {
public int addStudent(Student obj) throws StudentException;
public int deleteStudentById(int studentId) throws StudentException;
public Student getStudentById(int studentId) throws StudentException;
public ArrayList<Student>getAllStudent()throws StudentException;
public int updatePhoneNumber(int studentId,long phoneNumber)throws StudentException;
public int generateStudentId() throws StudentException;
 
}
