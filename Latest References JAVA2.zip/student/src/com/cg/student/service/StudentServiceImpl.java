package com.cg.student.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.student.beans.Student;
import com.cg.student.dao.StudentDao;
import com.cg.student.dao.StudentDaoImpl;
import com.cg.student.exceptions.StudentException;

public class StudentServiceImpl implements StudentService {
StudentDao dao;
	public StudentServiceImpl() {
	dao=new StudentDaoImpl();
	
	}

	@Override
	public int addStudent(Student obj) throws StudentException {
		// TODO Auto-generated method stub
		return dao.addStudent(obj);
	}

	@Override
	public int deleteStudentById(int StudentId) throws StudentException {
		// TODO Auto-generated method stub
		return dao.deleteStudentById(StudentId);
				}

	@Override
	public Student getStudentById(int StudentId) throws StudentException {
		// TODO Auto-generated method stub
		return dao.getStudentById(StudentId);
	}

	@Override
	public ArrayList<Student> getAllStudent() throws StudentException {
		// TODO Auto-generated method stub
		return dao.getAllStudent();
	}

	@Override
	public int updatePhoneNumber(int studentId, long phoneNumber)
			throws StudentException {
		// TODO Auto-generated method stub
		return dao.updatePhoneNumber(studentId, phoneNumber);
	}

	@Override
	public boolean validateName(String NAME) {
		String pattern= "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern, NAME)){
			return true;
		}else
			
		return false;
	}

	@Override
	public boolean validateId(int Id) {
		String pattern="[0-9]{3}";
		if(Pattern.matches(pattern,Id+""))
		{
			return true;
		}else
		return false;
	}

	@Override
	public boolean validatePhone(long Phone) {
		String pattern="[6-9]{1}[0-9]{9,9}";
		if(Pattern.matches(pattern, Phone+"")){
			return true;
		}else
		return false;
	}

	@Override
	public boolean validateAge(int Age) {
		String pattern="[0-9]{1}[0-9]{2}";
		if(Pattern.matches(pattern, Age+"")){
			return true;
		}
		return false;
	}

	@Override
	public int generateStudentId() throws StudentException {
		// TODO Auto-generated method stub
		return dao.generateStudentId();
	}

	public void setDao(StudentDao dao) {
		// TODO Auto-generated method stub
		this.dao=dao;
	}

	@Override
	public boolean isvalidEnquiry(Student st) {
		// TODO Auto-generated method stub
		if(!(validateName(st.getStdName()))){
			System.out.println("write correct name");
			return false;
		}
		if(!(validatePhone(st.getPhoneNumber()))){
			System.out.println("Write Valid phone number");
			return false;
		}
		if(!(validateAge(st.getAge()))){
			System.out.println("Write valid age");
			return false;
		}
		return true;	
	}

}
