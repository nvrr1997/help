package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;


public interface StudentService {
public int addStudent(Student obj)throws StudentException;
public int deleteStudentById(int StudentId)throws StudentException;
public Student getStudentById(int StudentId)throws StudentException;
public ArrayList<Student>getAllStudent()throws StudentException;
public int updatePhoneNumber(int studentId,long phoneNumber)throws StudentException;
public boolean validateName(String NAME);
public boolean validateId(int Id);
public boolean validatePhone(long Phone);
public boolean validateAge(int Age);
public int generateStudentId() throws StudentException;
public boolean isvalidEnquiry(Student st);

}
