package com.cg.student.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;





public class DBUtil {
	private static Connection con;
	static Logger logger=Logger.getLogger(DBUtil.class);
	public static Connection getConnection() {
		logger.info("get connection");
if (con == null) {
	try {
		FileReader reader = new FileReader("resource/jdbc.properties");
		Properties properties = new Properties();
		properties.load(reader);
		Class.forName(properties.getProperty("driver"));
		con = DriverManager.getConnection(
				properties.getProperty("url"),
				properties.getProperty("userName"),
				properties.getProperty("password"));

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		System.out.println(e.getMessage());
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}logger.info("end connection");
return con;
	}

public static void main(String[] args) {
System.out.println(DBUtil.getConnection());
System.out.println("//////////////////////");
System.out.println(DBUtil.getConnection());
}

}
